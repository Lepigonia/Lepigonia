"use client";

import { useCallback, useState } from "react";
import { adminApi } from "../lib/admin-api";
import { createBlogUploadPath, createGalleryUploadPath, uploadAdminBlob } from "../lib/admin-upload";

export function useAdminActions({ data, gallery, setGallery, setPost, setSection }) {
  const [galleryFiles, setGalleryFiles] = useState([]);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");

  const clearMessages = useCallback(() => {
    setError("");
    setStatus("");
  }, []);

  const refresh = useCallback(async () => {
    const result = await data.reload();
    if (result && !gallery && result.countries[0]) setGallery(result.countries[0].slug);
    return result;
  }, [data, gallery, setGallery]);

  const logout = useCallback(async () => {
    await adminApi.logout();
    window.location.reload();
  }, []);

  const savePost = useCallback(async (event, post) => {
    event.preventDefault();
    clearMessages();
    setStatus("Speichere …");
    try {
      const result = await adminApi.savePost(post);
      // Remember the new version of the file, so the next save of the same open post is not mistaken for a conflict.
      if (result?.sha) setPost((value) => (value.slug === post.slug ? { ...value, sha: result.sha } : value));
      setStatus("Gespeichert – Vercel veröffentlicht automatisch.");
      await refresh();
    } catch (err) {
      setError(err.message);
      setStatus("");
    }
  }, [clearMessages, refresh, setPost]);

  const deletePost = useCallback(async (slug, blankPost) => {
    if (!confirm("Beitrag wirklich löschen?")) return;
    clearMessages();
    try {
      await adminApi.deletePost(slug);
      setPost(blankPost());
      setSection("stories");
      await refresh();
    } catch (err) {
      setError(err.message);
    }
  }, [clearMessages, refresh, setPost, setSection]);

  const uploadHero = useCallback(async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    clearMessages();
    setStatus("Bild wird direkt zu Vercel Blob hochgeladen …");
    try {
      const blob = await uploadAdminBlob(createBlogUploadPath(file), file, (progress) =>
        setStatus(`Bild wird hochgeladen – ${Math.round(progress.percentage)}%`)
      );
      setPost((value) => ({ ...value, image: blob.url }));
      setStatus("Bild hochgeladen – jetzt speichern.");
    } catch (err) {
      setStatus("");
      setError(err.message || "Bild-Upload fehlgeschlagen.");
    }
  }, [clearMessages, setPost]);

  const uploadGallery = useCallback(async (files) => {
    if (!files.length || !gallery) return;
    setGalleryFiles(files);
    clearMessages();
    let done = 0;
    const failures = [];
    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      try {
        const blob = await uploadAdminBlob(createGalleryUploadPath(gallery, file), file, (progress) =>
          setStatus(`${index + 1} / ${files.length}: ${file.name} – ${Math.round(progress.percentage)}%`)
        );
        setStatus(`${index + 1} / ${files.length}: ${file.name} wird registriert …`);
        await adminApi.registerGalleryImage({ slug: gallery, url: blob.url, filename: blob.pathname });
        done += 1;
      } catch (err) {
        failures.push(`${file.name}: ${err.message}`);
      }
    }
    setGalleryFiles([]);
    await refresh();
    if (failures.length) {
      setError(`${done} von ${files.length} Bildern hinzugefügt.\n${failures.join("\n")}`);
      setStatus(done ? `${done} Galeriebild(er) hinzugefügt.` : "");
    } else {
      setStatus(`${done} Galeriebild(er) erfolgreich hinzugefügt.`);
    }
  }, [clearMessages, gallery, refresh]);

  const galleryAction = useCallback(async (body) => {
    clearMessages();
    try {
      const result = await adminApi.galleryAction(body);
      if (body.action === "country-update" && result.slug) setGallery(result.slug);
      await refresh();
    } catch (err) {
      setError(err.message);
    }
  }, [clearMessages, refresh, setGallery]);

  const saveAbout = useCallback(async (event, about) => {
    event.preventDefault();
    clearMessages();
    setStatus("About wird gespeichert …");
    try {
      await adminApi.saveAbout(about);
      setStatus("About gespeichert.");
    } catch (err) {
      setError(err.message);
      setStatus("");
    }
  }, [clearMessages]);

  return {
    galleryFiles,
    error,
    status,
    clearMessages,
    refresh,
    logout,
    savePost,
    deletePost,
    uploadHero,
    uploadGallery,
    galleryAction,
    saveAbout,
  };
}
